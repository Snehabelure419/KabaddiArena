package com.kabaddiarena

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            KabaddiApp()
        }
    }
}

@Composable
fun KabaddiApp() {

    // STATE
    var raidAttempts by remember { mutableIntStateOf(0) }
    var raidSuccess by remember { mutableIntStateOf(0) }
    var tacklePoints by remember { mutableIntStateOf(0) }

    // DATABASE
    val context = LocalContext.current
    val db = AppDatabase.getDatabase(context)
    val scope = rememberCoroutineScope()

    val total = raidSuccess + tacklePoints
    val successRate =
        if (raidAttempts == 0) 0 else (raidSuccess * 100 / raidAttempts)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Text("Kabaddi Arena", fontSize = 26.sp)

        Spacer(modifier = Modifier.height(20.dp))

        // CARD UI
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Raid Attempts: $raidAttempts")
                Text("Successful Raids: $raidSuccess")
                Text("Tackle Points: $tacklePoints")
                Text("Total Points: $total")
                Text("Success Rate: $successRate%")
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // RAID SUCCESS
        Button(
            onClick = {
                raidAttempts++
                raidSuccess++
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Raid Success")
        }

        Spacer(modifier = Modifier.height(10.dp))

        // RAID FAIL
        Button(
            onClick = {
                raidAttempts++
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Raid Fail")
        }

        Spacer(modifier = Modifier.height(10.dp))

        // TACKLE
        Button(
            onClick = {
                tacklePoints++
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Tackle +")
        }

        Spacer(modifier = Modifier.height(10.dp))

        // UNDO
        Button(
            onClick = {
                if (raidAttempts > 0) raidAttempts--
                if (raidSuccess > 0) raidSuccess--
                if (tacklePoints > 0) tacklePoints--
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Undo")
        }

        Spacer(modifier = Modifier.height(20.dp))

        // SAVE MATCH (ROOM DATABASE)
        Button(
            onClick = {
                scope.launch {
                    db.matchDao().insertMatch(
                        MatchEntity(
                            raidAttempts = raidAttempts,
                            raidSuccess = raidSuccess,
                            tacklePoints = tacklePoints,
                            totalPoints = total,
                            successRate = successRate
                        )
                    )
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Save Match 💾")
        }
    }
}